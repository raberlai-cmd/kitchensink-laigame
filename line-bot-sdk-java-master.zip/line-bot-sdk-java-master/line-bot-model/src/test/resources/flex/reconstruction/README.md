Flex reconstruction test resource
====

json files in this directly are used to json deserialize & serialize test.
